/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supershopfrontdesk;

/**
 *
 * @author aust_anik
 */
public class info {
    public String id;
    public String name;
    public String stock;
    public String price;
    public String type;
    public String weight;
    public String buy_price;
    public String barcode;
    public String vat;
    public String pwv;
}
